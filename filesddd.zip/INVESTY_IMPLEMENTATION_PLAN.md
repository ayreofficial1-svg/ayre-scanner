# Ayre v5 — Redesign Implementation Plan

**Status: Phases 0–5 complete, Phase 6 not started.** This is a living document — update the
"Phase Log" section at the bottom after completing each phase (files
changed, deviations, what remains) before starting the next phase.

**The app keeps the Ayre name — this is a visual redesign only, no
renaming.** This is **v5** of the app's design identity (v3 → v4 "calm,
editorial, premium" clay/rose/gold, both already in the codebase per the
`REDESIGN_*_CHANGES.md` files → **v5: forest-green/emerald, mint-paper
light theme, near-black-green dark theme**). §2A is the canonical, final
color specification for the whole theme system — every hex value needed to
implement both themes, app-wide, is written out there. No part of this
redesign is Home-tab-only: `AppThemeTokens` in `lib/theme/app_theme.dart`
is read by every screen in the app (§1), so landing §2A's values there
re-themes the entire app in one place.

## Scope

- **Flutter app only** (`ayre-scanner-app-main`). Never touch the backend
  (`ayre-scanner-main`) or its `frontend/` website — they were read for
  analysis only (see §3).
- **No renaming.** App name, package name, bundle/application IDs, and all
  `Ayre*` class/file names stay exactly as they are.
- **Full app-wide light + dark theme overhaul (v5)** using the exact
  colors in §2A, derived from the Home reference image. There is no
  reference image for dark mode — §2A's dark palette is an original,
  coherent counterpart in the same brand language, not an inversion.
- Apply structural/UX ideas from the Insights/Learn/Profile reference images,
  re-skinned in the Ayre v5 palette — never their orange accent.
- Remove all "Delayed" labels from market-data surfaces.
- Bypass the sign-in requirement (preserve the auth code for later).
- Do not invent chart/market data the backend doesn't supply.

## 1. Codebase map (verified by reading the source)

```
lib/main.dart                 — app root, theme wiring, startup gate, session-expired screen
lib/screens/
  home_shell.dart              — bottom-nav shell, IndexedStack of 5 tabs, tab fade transition
  home_tab.dart                — Home: greeting, sentiment, 3 index cards, market-insight carousel
  insights_tab.dart            — sentiment gauge, gainers/losers/most-active lists
  learn_tab.dart                — continue card + course list
  profile_tab.dart              — identity header + settings/support rows
  settings_screen.dart          — theme/text-size/notification rows
  signals_tab.dart, equity_detail_screen.dart, index_detail_screen.dart,
  edit_profile_screen.dart, notifications_screen.dart, support_screen.dart,
  login_screen.dart, splash_screen.dart, lesson_screen.dart
lib/services/
  api_service.dart              — HTTP + cookie session handling
  market_data_service.dart      — endpoint map, polling, parsing, local breadth fallback
  market_models.dart            — Quote/Course/etc. wire models
  settings_store.dart, fault_injection.dart
lib/theme/app_theme.dart        — AppThemeTokens (light/dark), AppRadius, AppMotion, AppTextScale,
                                   AppSpace, AppTypo — single source of truth for the whole design system
lib/widgets/
  ayre_bottom_nav.dart, ayre_charts.dart, ayre_components.dart, ayre_icons.dart,
  ayre_logo.dart, figure.dart, state_views.dart, ticker_trace.dart, spring.dart,
  pressable_scale.dart, responsive.dart
assets/brand/ayre_logo.png      — the only image brand asset
pubspec.yaml                    — package name `ayre_scanner`, version, asset list
android/, ios/, web/            — platform metadata (app label, bundle id, package id)
```

**Design system is already token-driven.** Every screen reads colors from
`context.tokens` (an `AppThemeTokens` instance) and spacing/type/radius from
`AppSpace`/`AppTypo`/`AppRadius`/`AppTextScale`. Re-theming is centralized —
changing `AppThemeTokens._light` / `._dark` in `app_theme.dart` re-colors the
whole app. No screen hardcodes a color. This plan relies on that and only
asks for structural changes where the reference images imply layout changes
`app_theme.dart` alone can't produce.

**Nav structure already matches the reference:** `HomeShell` already wires
Home / Signals / Insights / Learn / Profile in that order through
`AyreBottomNav`, and `settings_screen.dart` / `profile_tab.dart` are already
structured close to the reference (header block + grouped rows, theme
segmented control, text-size 3-way control). Treat Phase 6 as **re-skin +
targeted layout adjustment**, not a rebuild.

## 2. Reference image analysis (for an implementer with no image access)

### 2.1 Home — establishes the palette and overall identity

**Palette.** The whole surface is a very pale, slightly cool mint/off-white
— not pure white. Text and the wordmark sit in a deep, almost-black forest
green (not pure black) for primary content, which doubles as the brand's
"ink" color. There is no single loud accent color; instead each data
surface carries its **own** soft tint that signals what it is: a muted
sage/mint green tint (NIFTY 50, the LIVE dot, positive deltas), a soft
coral/peach tint (the SENSEX card — a card-identity color, not a
gain/loss color: SENSEX is up in the reference and still reads in warm
coral), a soft powder-blue tint (BANK NIFTY), and a near-black forest-green
solid fill for the one hero editorial block (the "Market Insight" carousel
card). The floating "Market Sentiment" card reuses the mint family, with
"Bullish" set large and bold in a saturated green plus an up-right arrow
glyph.

Read this as: **one neutral paper background + one deep ink color for text/
brand, a small family of muted pastel tints used as per-card identity
color, and full-saturation green/red reserved for actual gain/loss figures
and glyphs.** This is the same *discipline* the current `AppThemeTokens`
already encodes (accent / positive / negative / neutral as separate roles)
— only the hue family changes, from v4's clay/terracotta to an
emerald/sage family, and the background shifts from warm cream to cool
mint-white. **§2A below converts this reading into exact, final hex
values — implement colors from §2A directly, this paragraph is the
reasoning behind them, not a second source to re-derive from.**

**Typography hierarchy.** A large, bold, tight-tracked headline
("Good afternoon, / Raghav" — the name noticeably bigger/bolder than
"Good afternoon,") sits above a muted one-line subhead ("Discipline today.
A better tomorrow."). Section labels ("Indian Indices") are mid-weight, not
uppercase-eyebrow style. Numeric index values are the single largest,
boldest text on each card — clearly heavier and larger than any label
around them. Percentage/point change sits directly under the price, smaller
and colored by direction. This hierarchy — hero number > row label >
caption — already exists as `AppTypo.heroValue` / `rowLabel` / `hint`; no
new type roles are needed, only recoloring.

**Card structure & density.** Each index card is a single self-contained
unit: a **circular** icon tile with a soft radial-gradient glow (tinted to
the card's identity color — see §2A) + index name + exchange sub-label on
one line, a "LIVE" pill in the opposite top corner, a large price line, a
change line, a small sparkline (with a gradient area-fill under the line,
not a flat fill) occupying the right portion of the card at the same
vertical position as the price, a row of period tabs (1D/1W/1M/1Y — the
active one a solid filled pill in a deeper shade of the card's own tint)
directly under the sparkline, and finally a thin-divided row of three
compact stats (Open / Day High / Day Low) along the bottom. Cards are
generously sized (more internal breathing room than a dense list row) and
stack with clear separation — this reads as **3 cards, not a list**, each
roughly as tall as it needs to show all of the above, not a compact ticker
row. Corner rounding on the *card itself* is soft but not pill-shaped — a
clearly rounded rectangle, matching the app's existing card radius. The
icon tile is the one deliberate exception to the app's usual
rounded-square icon-tile rule — see §2A's "Icon-tile shape override" note.

**Avatar / identity accent.** The circular "R" initials avatar in the
header is a distinct **lavender/plum** tone — not the brand green used
everywhere else. Treat this as a deliberate secondary accent reserved for
personal-identity chips (the header avatar, and the equivalent circle on
the Profile tab) and never reuse it for market data, buttons, or
navigation. Exact values are in §2A's Component table.

**The "Market Insight" carousel** is a distinct, dark, full-bleed card at
the bottom of the scroll: a small uppercase eyebrow label, a bold two-line
headline, a muted one-line description, a pill-shaped "Read more" button
with a trailing arrow, and a top-right pager control (‹ 01/04 ›). It also
carries a decorative abstract ascending-bar-chart flourish in its
bottom-right corner, sitting inside a soft radial green glow — purely
decorative, not a real data chart (see §3 for why no real chart is used
here or anywhere else).

**Header utility buttons.** Search and notification-bell sit as two small
white circular icon buttons top-right, with the bell carrying a small red
unread-count dot — flat icon buttons, not gradient, colors in §2A's
Component table.

**Header decoration.** Behind the greeting text sits a soft, large,
layered abstract shape (like overlapping translucent hills/waves) in the
same mint tint family, bleeding off the top-right of the screen. It is pure
ornament, not a data visualization — note this explicitly so it isn't
mistaken for a chart.

**Navigation.** A floating, fully rounded (pill) bar anchored to the
bottom, icon + label per tab, with the active tab shown as a solid dark
pill (filled with the deep ink/forest-green tone) wrapping just its own
icon+label, while inactive tabs are plain icon+label in muted gray. This
matches the app's existing `AyreBottomNav` pill-and-active-fill pattern —
re-skin its colors only, no structural change needed.

### 2.2 Insights — structural/UX ideas only, ignore its orange palette

- A **market-sentiment gauge card** at the top: a large semicircular arc
  gauge with a numeric score and a qualitative label underneath (e.g.
  "65/100 — STRONG"), paired beside a short written takeaway ("Positive
  momentum across sectors") and a one-line supporting stat with a small
  trend glyph. This is structurally close to what `insights_tab.dart`
  already renders (doc comments confirm a sentiment gauge already exists)
  — keep the layout, re-skin the colors, and only change copy/values that
  currently reference "Delayed" (§4).
- **Grouped mover lists** (Top Gainers / Top Losers / Most Active), each
  with an uppercase section label and a "See all" affordance top-right, then
  a compact list of rows: a small square logo/initial tile, company name +
  ticker sub-label, price, and colored delta on the trailing edge, with a
  small sparkline before the price. **Do not add the per-row sparkline** —
  §3 confirms the backend supplies no series data for movers. Keep the row
  otherwise (tile, name, ticker, price, colored delta) since all of that is
  real data already available.
- Takeaway: dense, scannable list rows grouped under clear section headers
  with a consistent "See all" pattern — apply this row grammar (tile + two
  text lines + trailing value/delta) anywhere the app lists tradeable
  instruments, replacing any structurally different list styling.

### 2.3 Learn — structural/UX ideas only, ignore its orange palette

- A page header with a small uppercase eyebrow ("TRADING LIBRARY"), a large
  bold page title, and a muted one-line subhead — matches the Home
  header's hierarchy, reuse the same type roles.
- Two small stat tiles side by side under the header (e.g. "0 Subjects",
  "0 Courses") — compact, icon-less, just a bold number over a muted label.
- A horizontal pill-tab filter row (All / Basics / Technical / Fundamental /
  Psychology) with the active pill filled solid in the accent color.
- A calm, centered empty state: a small illustrative glyph, a bold one-line
  message, a muted one-line explanation, and a small circular "pull to
  retry" affordance. `learn_tab.dart` / `state_views.dart` already have an
  empty-state concept — re-skin it toward this calmer, more centered
  composition rather than a dense error block.
- A footer info card (icon tile + short heading + description) — same card
  language as everywhere else, just used for a static informational blurb.

### 2.4 Profile / Settings — structural/UX ideas only, ignore its orange palette

- Profile header: circular avatar/initials, name, handle, a small pill tag
  in the top-right corner of the header card (e.g. a mood/streak tag), a
  muted tagline, and an "Edit Profile" pill button.
- Two stat tiles under the header (icon + number + label), e.g. alerts
  logged / unread insights — same tile pattern as Learn's stat tiles.
  Reuse one shared stat-tile component instead of building this twice.
- Rows grouped under small uppercase section labels (ACCOUNT / PREFERENCES
  / SUPPORT / ABOUT), each row: leading label + optional description on two
  lines, trailing value and/or chevron. This already matches
  `profile_tab.dart` / `settings_screen.dart` — re-skin only.
- Settings' appearance section: a two-up segmented control for Light/Dark
  (each option a full tile with a glyph, label, and a checkmark on the
  selected one, not a thin segmented bar) and a three-up segmented control
  for text size (Small/Default/Large, each showing "Aa" at a different
  scale). `settings_screen.dart` already has a theme selector and text-size
  control — adjust their visual weight to this "big tappable tile" style if
  the current implementation renders them as a thinner bar; keep the
  underlying logic untouched.
- Toggle rows (in-app alerts, new signal alerts, etc.) use a simple label +
  description + trailing switch — matches `AyreSwitch` usage already in the
  app.

## 2A. Ayre v5 — canonical color specification

**This is v5 of the app's design identity** (v4 was the "calm, editorial,
premium" clay/rose/gold system currently in `app_theme.dart` — v5 replaces
it entirely with the emerald/forest-green identity below). **These hex
values are final and app-wide** — they apply to `AppThemeTokens._light`
and `AppThemeTokens._dark` in `lib/theme/app_theme.dart`, which is the
single source of truth every screen in the app already reads from (§1). Do
not re-derive colors from the reference image; implement the values in this
section directly. There is no reference image for dark mode — the dark
palette below is an original, coherent extension of the same brand
(forest-green ink, emerald accent, sage/rose/gold semantics), not an
inversion of light mode, matching the design discipline the current v4
file's own comments already insist on.

Every color is given as Flutter `Color(0xAARRGGBB)` (8-digit, alpha first)
so opacity-bearing tokens (hairlines, soft fills) are unambiguous.

#### Core tokens — `AppThemeTokens` fields (replaces `_light`/`_dark` in `app_theme.dart`)

| Token | Light | Dark | Role / notes |
|---|---|---|---|
| `background` | `Color(0xFFF1F7F1)` | `Color(0xFF0B120D)` | App canvas. Pale cool mint-white (light) / near-black with a green cast, never pure gray or pure black (dark). |
| `surface` | `Color(0xFFFFFFFF)` | `Color(0xFF121A14)` | Default card/panel fill, one step off `background`. |
| `surfaceRaised` | `Color(0xFFE9F2E9)` | `Color(0xFF1B261E)` | Tile lifted off its parent surface (icon tiles, nested tonal blocks). |
| `surfaceSunken` | `Color(0xFFE1EDE1)` | `Color(0xFF080D09)` | Recessed fill (insets, tracks). |
| `accent` | `Color(0xFF1F8A4B)` | `Color(0xFF3FCB7A)` | Primary brand green — matches "Bullish" text, up-arrows, NIFTY trace, primary buttons, active nav elements, links. Brighter/more saturated in dark mode so it still reads as the loudest color against a near-black field. |
| `accentInk` | `Color(0xFF166B3A)` | `Color(0xFF59D98C)` | Darkened (light) / lightened (dark) accent variant for small-type-weight use (links, selected labels) where raw `accent` doesn't clear 4.5:1 as text on that theme's surfaces — verify numerically per the existing file convention, only populate where it actually differs from `accent`. |
| `accentSoft` | `Color(0xFFCFE8D8)` | `Color(0xFF1E3B29)` | Accent held back for large, low-emphasis fills. |
| `onAccent` | `Color(0xFFFFFFFF)` | `Color(0xFF06130A)` | Text/icon on an `accent` fill — white in light (accent is mid-dark there), near-black ink in dark (accent is bright/mid-light there), same "verify contrast, don't assume" rule the current file documents. |
| `positive` | `Color(0xFF1F8A4B)` | `Color(0xFF4ED892)` | Gain figures, up glyphs. Same hue family as `accent` but kept as its own field per the existing token contract (a screen may want brand-accent and gain-color to diverge later). |
| `positiveSoft` | `Color(0xFFDCEEE0)` | `Color(0xFF16301F)` | Large low-emphasis positive fill. |
| `negative` | `Color(0xFFD64545)` | `Color(0xFFF0685F)` | Loss figures. A clear red — distinct from the SENSEX card's coral identity tint (§ table below), which is never a loss signal. |
| `negativeSoft` | `Color(0xFFF7DCDC)` | `Color(0xFF3A1917)` | Large low-emphasis negative fill. |
| `neutral` | `Color(0xFFC98A2D)` | `Color(0xFFE0B563)` | Attention/neutral role (e.g. a flat/unchanged badge) — muted gold/amber, never a button fill, never navigation, never brand. |
| `neutralSoft` | `Color(0x24C98A2D)` | `Color(0x24E0B563)` | 14%-alpha wash of `neutral`. |
| `textPrimary` | `Color(0xFF16211B)` | `Color(0xFFEDF5EE)` | Primary reading text / the wordmark ink color. Near-black forest-green (light), soft off-white with a faint green cast (dark). Must clear 4.5:1 on `background` and `surface` in both themes. |
| `foregroundMuted` | `Color(0xFF5B6B60)` | `Color(0xFF9FB0A4)` | Secondary text — captions, timestamps, supporting copy. |
| `foregroundSubtle` | `Color(0xFF8B968E)` | `Color(0xFF67766C)` | Tertiary text — eyebrows, micro-labels only. |
| `textDisabled` | `Color(0x808B968E)` | `Color(0x8067766C)` | `foregroundSubtle` at 50% alpha, per the existing derivation rule. |
| `hairline` | `Color(0x141A2E22)` | `Color(0x14CFE8D5)` | 1px card edge / divider — dark-green-tinted hairline on light, mint-tinted hairline on dark, each ~8% alpha over its own background. |
| `navHairline` | `Color(0x1F1A2E22)` | `Color(0x1FCFE8D5)` | Slightly stronger hairline for the bottom-nav's top edge (~12% alpha). |
| `shadowColor` | `Color(0xFFB9CBBB)` | `Color(0xFF000000)` | Two-layer soft card shadow base — a muted sage-gray in light mode (never pure black on a light theme), pure black in dark mode (already dark, so a colored shadow would just muddy edges). |
| `navBg` | `Color(0xFFFFFFFF)` | `Color(0xFF101911)` | Base fill for the glass bottom nav, composited with alpha + blur at the call site as the current `AyreBottomNav` already does. |
| `skeleton` | `Color(0xFFE7EEE8)` | `Color(0xFF1B261E)` | Base tone for loading shimmer, before the foreground-tinted gradient sweep. |

#### Index-card identity tints (new — not part of `AppThemeTokens`, see Phase 0 step 6)

Each of the three Home index cards (and anywhere else an index is
represented as a card, e.g. `index_detail_screen.dart`'s header) carries
its own identity tint, independent of gain/loss color:

| Index | Role | Light | Dark |
|---|---|---|---|
| NIFTY 50 | card background | `Color(0xFFE7F3E8)` | `Color(0xFF14251A)` |
| | icon-tile gradient center → edge | `Color(0xFFDFF0E2)` → `Color(0xFFB8DEC0)` | `Color(0xFF25452F)` → `Color(0xFF15291C)` |
| | trace/glyph color | `Color(0xFF2E9E5B)` | `Color(0xFF4ED892)` |
| | active period-tab pill fill | `Color(0xFFC9E4CE)` | `Color(0xFF255436)` |
| SENSEX | card background | `Color(0xFFFBEAE4)` | `Color(0xFF2A1B14)` |
| | icon-tile gradient center → edge | `Color(0xFFFAE2D8)` → `Color(0xFFEEC3AF)` | `Color(0xFF4A2E1F)` → `Color(0xFF2C1911)` |
| | trace/glyph color | `Color(0xFFD97757)` | `Color(0xFFE08A63)` |
| | active period-tab pill fill | `Color(0xFFF3D2C3)` | `Color(0xFF5A3624)` |
| BANK NIFTY | card background | `Color(0xFFE6EEF7)` | `Color(0xFF131E2A)` |
| | icon-tile gradient center → edge | `Color(0xFFDCEAF6)` → `Color(0xFFB9D3EB)` | `Color(0xFF213D57)` → `Color(0xFF122333)` |
| | trace/glyph color | `Color(0xFF4A79B5)` | `Color(0xFF6FA8E0)` |
| | active period-tab pill fill | `Color(0xFFCBE0F3)` | `Color(0xFF29476A)` |

These are **decorative per-card identity colors**, matched to each index's
existing icon in the reference (a green up-trend glyph for NIFTY, a
bar-chart glyph for SENSEX, a bank/column glyph for BANK NIFTY) — they are
not semantic gain/loss colors and must never be swapped in for
`positive`/`negative`. If a fourth index is ever added, extend this table
with a new row in the same style rather than reusing an existing tint.

**Icon-tile shape override:** the app's general icon-tile rule
(`AppRadius.iconTile`, rounded-square, "circles reserved for avatars only")
stays the default everywhere else in the app. The Home/index-card icon tile
is the one deliberate exception the reference image shows clearly: it is
**circular**, with the soft two-stop radial gradient given above (center
lighter, edge darker, same hue family) producing a subtle glow behind the
glyph. Implement this one component as a `RadialGradient`-filled `CircleAvatar`
or `DecoratedBox` with `shape: BoxShape.circle`, not `AppRadius.iconTile`.
Do not carry the circular treatment to any other icon tile in the app.

#### Component-specific colors

| Component | Light | Dark |
|---|---|---|
| Market Insight hero card (bottom-of-Home carousel) — base fill | Linear gradient, top-left → bottom-right: `Color(0xFF0F1D15)` → `Color(0xFF16281C)` | Linear gradient: `Color(0xFF060B07)` → `Color(0xFF0D1710)`, plus a 1px `Color(0x333FCB7A)` (accent at 20% alpha) hairline border so the card still reads as a distinct surface against an already-dark page |
| — bar-chart art glow (behind/around the decorative ascending-bars graphic, bottom-right of the card) | Radial gradient centered under the bars: `Color(0x402E9E5B)` (accent-green at 25% alpha) fading to `Color(0x002E9E5B)` (0% alpha) — see Gradients table below for the bars themselves | Radial gradient: `Color(0x554ED892)` fading to `Color(0x004ED892)` |
| — eyebrow label text | `Color(0xFF9FD9AE)` | `Color(0xFF6FCB93)` |
| — headline text | `Color(0xFFFFFFFF)` | `Color(0xFFF5FFF8)` |
| — description text | `Color(0xFFC7D4CB)` | `Color(0xFFAEC2B3)` |
| — "Read more" pill button fill | `Color(0xFF24382C)` | `Color(0xFF1E3B29)` |
| — "Read more" pill button text | `Color(0xFFFFFFFF)` | `Color(0xFFEDF5EE)` |
| — pager arrow buttons (‹ ›) fill | `Color(0x1FFFFFFF)` (white at 12% alpha, circular) | `Color(0x1FFFFFFF)` (same — already dark-appropriate) |
| — pager "01/04" text | `Color(0xFFB9C7BD)` | `Color(0xFF8FA396)` |
| Market Sentiment card — background | Gradient `Color(0xFFDCEEDF)` → `Color(0xFFEAF5EC)` | Gradient `Color(0xFF14251A)` → `Color(0xFF0F1D15)` |
| — "Market Sentiment" label + small bar-chart icon | `Color(0xFF4F6357)` | `Color(0xFF9FB0A4)` |
| — "Bullish"/"Bearish"/"Neutral" value + arrow glyph | `positive`/`negative`/`neutral` per §5 Phase 2's bucketing (reuse the core tokens, don't hardcode a new color here) | same |
| — description line | `Color(0xFF64766B)` | `Color(0xFF9FB0A4)` |
| Header decorative hill shapes (2–3 overlapping soft silhouettes behind the greeting, bleeding off the top-right) | `accent` at low alpha, layered outward-to-inward: `Color(0x0A1F8A4B)`, `Color(0x141F8A4B)`, `Color(0x1F1F8A4B)` (furthest-back shape lowest alpha) | `accent` (dark) layered: `Color(0x0C3FCB7A)`, `Color(0x163FCB7A)`, `Color(0x203FCB7A)` |
| Sparkline area fill (under each `TickerTrace` line, index cards + any other chart in the app) | Linear gradient, top → bottom, using that chart's own trace/tone color: solid color at 30% alpha → same color at 0% alpha | Same trace color, top → bottom: 35% alpha → 0% alpha (slightly higher start-alpha so the fill still reads against the darker card) |
| Sentiment gauge arc (Insights tab — semicircular progress arc) — filled portion | `accent` `Color(0xFF1F8A4B)` (solid, no gradient — matches the reference's flat-filled arc) | `accent` `Color(0xFF3FCB7A)` |
| — unfilled track | `surfaceSunken` `Color(0xFFE1EDE1)` | `surfaceSunken` `Color(0xFF080D09)` |
| — end-cap dot marker | `accent` (light) / `accent` (dark), same as filled portion, slightly larger radius | same |
| — "STRONG"/qualitative-label pill | text `accentInk` on fill `accentSoft` | text `accentInk` on fill `accentSoft` |
| Circular header icon buttons (search, notification bell) — fill | `Color(0xFFFFFFFF)` | `surfaceRaised` `Color(0xFF1B261E)` |
| — icon color | `textPrimary` `Color(0xFF16211B)` | `textPrimary` `Color(0xFFEDF5EE)` |
| — notification unread badge dot | `negative` `Color(0xFFD64545)` (a true alert red — reuse the core `negative` token rather than inventing a new badge color) | `negative` `Color(0xFFF0685F)` |
| Avatar / identity chip (profile initials circle, e.g. the header "R") — **a deliberate secondary accent, distinct from brand green**, used only for personal/identity chips, never for market data | fill `Color(0xFFE1DDF5)`, initials text `Color(0xFF4B3F73)` | fill `Color(0xFF241F38)`, initials text `Color(0xFFC9BFEA)` |
| Profile header decorative blob (same "soft layered shape" device as the Home header, top-right of the identity card) | `accent` layered at low alpha, same 3-stop recipe as the Home header shapes above | same dark recipe as the Home header shapes above |
| Profile "mood/streak" tag pill (e.g. "PATIENCE") | text `accentInk`, fill `accentSoft` | text `accentInk`, fill `accentSoft` |
| Theme/text-size selector tiles (Settings — big tappable tiles, §2.4) — selected tile fill | `accent` `Color(0xFF1F8A4B)`, content `onAccent` `Color(0xFFFFFFFF)` | `accent` `Color(0xFF3FCB7A)`, content `onAccent` `Color(0xFF06130A)` |
| — unselected tile fill/content | fill `surfaceRaised`, content `foregroundMuted` | fill `surfaceRaised`, content `foregroundMuted` |
| Toggle switches (`AyreSwitch`) — on/off track | on: `accent`; off: `surfaceSunken` | on: `accent`; off: `surfaceSunken` |
| Bottom nav — bar fill | `navBg` at ~90% alpha + blur (existing mechanism) | `navBg` at ~85% alpha + blur |
| — bar shape | full pill / large-radius rounded bar (not the card radius), floating with margin from the screen edges, `shadowColor`-based soft shadow beneath | same shape, shadow reads as pure black per §2A's dark `shadowColor` |
| — active tab pill fill | `Color(0xFF16211B)` (= `textPrimary`, the deep ink green) | `accent` `Color(0xFF3FCB7A)` |
| — active tab icon/label | `Color(0xFFFFFFFF)` | `onAccent` `Color(0xFF06130A)` |
| — inactive tab icon/label | `Color(0xFF8B948E)` | `foregroundMuted` `Color(0xFF9FB0A4)` |
| LIVE chip | dot + text `positive` `Color(0xFF1F8A4B)` on `positiveSoft` `Color(0xFFDCEEE0)` pill, regardless of the card's own identity tint | dot + text `positive` `Color(0xFF4ED892)` on `positiveSoft` `Color(0xFF16301F)` pill |

#### Gradients — full inventory (every gradient in the v5 theme, nothing else in the app should use a gradient)

| # | Where | Type | Stops |
|---|---|---|---|
| 1 | Market Insight hero card base | Linear, top-left → bottom-right | See Component table row 1 |
| 2 | Market Insight hero card bar-chart glow | Radial, centered behind the bar-art | See Component table row 2 |
| 3 | Market Sentiment card background | Linear, top → bottom | See Component table |
| 4 | Index-card icon tile | Radial, centered | See Index-card table |
| 5 | Sparkline area fill (every `TickerTrace` with `fill: true`) | Linear, top → bottom | See Component table |
| 6 | Header + Profile-header decorative hill shapes | Flat alpha layers (not a true multi-stop gradient — three separately-alpha'd shapes stacked, per the Component table) | — |

No other component in the app (buttons, chips, list rows, nav, settings
tiles) uses a gradient — everything else is a flat token color per §2A's
core table, matching the app's existing (v4) discipline of flat fills with
soft shadows rather than gradients as the default.

#### Typography — unchanged from v4, carried into v5

Fonts stay Hanken Grotesk (body/heading/UI) + Space Grotesk (all numeric/
tabular figures), and the existing `AppTextScale`/`AppSpace`/`AppRadius`
values stay as-is (§5 Phase 0) — v5 is a color (plus the one icon-tile
shape exception above) identity change, not a type-scale or spacing-scale
change. Only `AppTypo`'s color *arguments* change, automatically, by
reading the new tokens above.

## 3. Backend data investigation (read-only — do not modify backend)

Verified directly in `ayre-scanner-main`:

- `GET /api/market` (`main.py`, `_normalize_market_item` /
  `_build_market_payload`) returns, per index, only `name`, `value`,
  `change` (%), and `points` (absolute) — from every source path (NSE,
  Fyers, Yahoo fallback in `_fetch_market_from_*`). **No intraday
  series/candle data, no open/high/low, no previous close** is included for
  indices, regardless of source.
- `data/candles.py` contains Fyers historical-candle fetch logic, but it is
  **not wired to any `@app.route`** — nothing in `main.py` exposes candle
  history over HTTP. It's used internally by the scanner, not by any
  consumer-facing endpoint.
- `GET /api/market/gainers|losers|most-active` (`_get_movers_payload`)
  return per-stock `last_price`, `change_pct`, `volume`, etc., but likewise
  **no series/trace field**.
- `GET /api/market/<key>/constituents` returns `last_price`, `change_pct`,
  `change_points`, `open`, `high`, `low`, `year_high`, `year_low`, `volume`,
  `market_cap` per stock — real O/H/L exists **only for individual
  constituent stocks**, not for the three top-level indices.
- `GET /api/sentiment` returns a hand-set 0–100 `sentiment` score, an
  optional admin-set `note`, and — only once the live Fyers WebSocket has
  ticked enough symbols — real `advances`/`declines`/`unchanged` counts
  (omitted, not zeroed, until then).

**Conclusion:** the Flutter app's `Quote.trace` field (already present in
`market_models.dart`, already rendered conditionally by `TickerTrace` only
when `trace.length >= 2`) has no real backing data source for indices today,
and the same is true for gainers/losers. **Do not populate it with fake
data and do not build the reference's sparkline-plus-period-tabs UI or an
Open/Day-High/Day-Low row for index cards** — no endpoint supplies either
for indices. Leave the existing `trace` plumbing and its length check
exactly as-is (it already degrades gracefully to "don't draw" and will
start working automatically if the backend ever adds the field) but replace
the *visual space* the reference reserves for the graph — see §5, Phase 3.

The 0–100 sentiment score, the optional note, and the advances/declines
counts **are** real and can back the redesigned Home sentiment card (§5,
Phase 2).

## 4. "Delayed" label inventory — remove in every location

| File | Context | Action |
|---|---|---|
| `lib/screens/home_tab.dart` (~L578) | Index card chip: `stale ? Chip('Delayed') : Chip('Live', pulse)` | When stale, render nothing in that slot (`SizedBox.shrink()`) instead of a "Delayed" chip — don't claim data is live when it isn't, but don't display the word either. |
| `lib/screens/equity_detail_screen.dart` (~L204) | Same stale/live chip pattern | Same fix. |
| `lib/screens/index_detail_screen.dart` (~L290) | Same stale/live chip pattern | Same fix. |
| `lib/widgets/state_views.dart` `FreshnessStamp` (~L455-462) | Shows `Chip('Delayed')` when `stale`, else "AS OF hh:mm" | Always render the "AS OF hh:mm" branch; drop the `stale` conditional and the chip branch entirely. |
| `lib/widgets/ayre_components.dart` (~L182, 531, 1323, 1410) | Doc comments referencing "DELAYED" as an example chip state | Update comments only — no user-facing text, low priority, do in the same pass for consistency. |
| `lib/widgets/ayre_icons.dart` `AyreGlyph.delayed` (~L61, 448) | Icon glyph used by the chip/stamp above | Keep the glyph (harmless, may still be referenced by settings' notification-type icon in `settings_screen.dart`/`notifications_screen.dart`), just stop using it in the two removed chip contexts. |
| `lib/screens/settings_screen.dart` (~L145-146) / `notifications_screen.dart` (~L53, 90-93) | "Delayed-data warnings" notification **preference name** — a settings toggle label, not a market-data display | Out of scope for this removal (it's not a market-data display, it's a user notification-preference setting) — leave the toggle, just verify it still makes sense with the chip removed (it does: it's about push/log notifications when data goes stale, independent of the visual chip). |
| `test/fault_states_test.dart` (~L237) | Asserts `find.text('DELAYED')` exists | Update this test to assert the chip/stamp is absent when stale, matching the new behavior. |
| `test/identity_test.dart` (~L342) | References `AyreGlyph.delayed` | No change needed — the glyph itself isn't being renamed. |

## 5. Phases

Each phase must end with: the app in a working, internally consistent
state; the "Files changed" list below updated in §7; and only the files
touched in that phase delivered individually (no zip).

### Phase 0 — Theme tokens: light + dark palettes (Ayre v5)

Rebuild the two `AppThemeTokens` instances (`_light`, `_dark` in
`app_theme.dart`) using **exactly** the hex values in §2A's core-token
table — this is a value swap, not a redesign-on-the-fly: every field name
already exists in `AppThemeTokens` and every screen already reads it via
`context.tokens`, so plug in §2A's numbers directly rather than
re-interpreting the reference image.

1. Replace every `Color(0x...)` literal in `_light` and `_dark` with §2A's
   core-token table values, field for field. Do not add or remove any
   `AppThemeTokens` field — the existing field set already covers
   everything v5 needs.
2. Update every doc comment in `app_theme.dart` that names the retiring
   "clay/terracotta", "sage/rose/gold", or "v4 calm, editorial, premium"
   identity — rewrite them to describe v5's forest-green/emerald identity
   (mirroring §2A's own language), so the file stays accurate as
   documentation. Retitle the file's top banner comment from "v4" to "v5".
3. Verify contrast for every `textPrimary`/`foregroundMuted`/
   `foregroundSubtle` pairing against `background` and `surface` in both
   themes (≥4.5:1 for `textPrimary`, per the field's existing doc
   requirement) and for `onAccent` against `accent` — §2A's values were
   chosen for this, but confirm numerically and flag here if any pairing
   needs a small adjustment, rather than silently changing a value.
4. `AppRadius`, `AppSpace`, `AppTextScale`, and the fonts in `AppTypo`
   (Hanken Grotesk + Space Grotesk) stay exactly as they are — v5 is a
   color and (for Home) light structural identity change, not a type-scale
   or spacing-scale change.
5. Do **not** invent any color not listed in §2A. If a screen in a later
   phase needs a color §2A doesn't cover, derive it from an existing token
   (e.g. an alpha wash of `accent`/`positive`/`negative`/`neutral`) and
   record the new derived value in that phase's log entry — don't pick an
   arbitrary new hue.
6. **Index-card identity tints** (§2A's second table) are not
   `AppThemeTokens` fields — add them as a small new static lookup near
   where they're consumed (e.g. a `const Map<IndexId, _IndexTint>` in
   `home_tab.dart`, or a tiny new `AppIndexTints` class in `app_theme.dart`
   if `index_detail_screen.dart` also needs them in Phase 7 — pick one
   location and use it from both places rather than duplicating the table).
   Implement with the exact light/dark hex pairs from §2A and switch on
   `Theme.of(context).brightness` the same way the rest of the app already
   themes conditionally.

### Phase 1 — Shared components pass

Re-skin (colors only, from Phase 0's new tokens) `ayre_components.dart`,
`ayre_charts.dart`, `ayre_bottom_nav.dart`, `ayre_icons.dart`,
`state_views.dart`, `figure.dart`, `ticker_trace.dart` — confirm nothing
hardcodes an old clay/rose/gold hex value outside the token file (grep for
literal `Color(0x...)` in these files; any found outside `app_theme.dart`
is a bug to fix here, not a v4 leftover to leave). Verify the bottom nav's
active-pill fill and the sentiment/gain/loss glyphs read correctly against
both new themes.

**Phases 2–7 below replace what was originally a single Phase 2 (Home tab)
and a single Phase 3 (Insights/Learn/Profile/Settings + secondary screens) —
each was too much work for one pass, so they're split along natural file/
section boundaries to keep each phase's token footprint small. No scope was
added or removed in the split; every step below traces back to a step in
the original two phases. The old Phase 4 (auth verification) is folded into
the end of Phase 7 since it's a quick check, not new work.**

### Phase 2 — Home tab: header & sentiment card

Covers only the top portion of `home_tab.dart` — the index cards, graph
area, and Market Insight carousel are deferred to Phase 3 so this phase
stays small. Recolor per §1 (automatic once Phase 0/1 land).

1. Remove the "Delayed" chip per §4's table (`home_tab.dart` entry):
   render `SizedBox.shrink()` in that slot instead of the stale-state chip.
2. **Header:** verify the greeting/subhead typography hierarchy (§2.1)
   against `AppTypo` roles — recolor only, no new type roles needed.
   Recolor the two circular header icon buttons (search, notification
   bell) and the unread-count dot per §2A's Component table. Recolor the
   decorative layered "hill" shapes behind the greeting per the Component
   table's alpha-layered `accent` values — purely ornamental, confirm it
   isn't mistaken for a chart.
3. **Sentiment card:** restructure the existing breadth donut/sentiment
   gauge section into a card matching §2.1's "Market Sentiment" treatment —
   bucket the real `/api/sentiment` 0–100 score into a short label (e.g.
   ≥60 "Bullish", 40–59 "Neutral", <40 "Bearish" — pick real, sensible
   breakpoints and state them in this phase's log entry) shown large and
   bold with a directional arrow glyph, plus a one-line description sourced
   from the API's real `note` field when present, falling back to a
   description derived from the real `advances`/`declines` counts when
   available (e.g. "X of Y stocks advancing"), and only a generic static
   line (no invented numbers) when neither is available. Do not invent a
   sentiment description string that implies data not actually returned.
   Recolor per the Component table's "Market Sentiment card" rows.

**Out of scope here (Phase 3):** the three index cards and the Market
Insight carousel.

### Phase 3 — Home tab: index cards, graph area & Market Insight carousel

Finishes `home_tab.dart`. Recolor per §1 (automatic).

1. Verify index-card structure against §2.1 (circular icon tile +
   name/exchange, LIVE pill, hero price, delta row, "VIEW CONSTITUENTS"
   link) — this structure already exists in `home_tab.dart`, so this is
   confirmation, not a rebuild. Apply the circular icon-tile override
   (§2A "Icon-tile shape override") and the per-index identity tints (§2A's
   Index-card identity tints table, added in Phase 0 step 6).
2. **Graph area decision (§3):** since no real per-index series/O-H-L data
   exists, do not add a sparkline or period tabs. Replace that card region
   with a small decorative flourish in the card's own identity tint —
   mirroring the purely-ornamental layered-arc graphic already used behind
   the Home greeting header in the reference (§2.1) — sized to roughly
   occupy the sparkline's former footprint so the card doesn't look bare.
   Implement as a lightweight `CustomPainter` (soft overlapping
   translucent arcs/shapes in `tone.withValues(alpha: ...)`), not an
   image asset. Keep the existing `if (quote.trace.length >= 2)` branch
   exactly as-is beneath/alongside it so a real sparkline still takes over
   automatically the day the backend adds trace data — the decorative
   flourish only renders in the empty-trace branch.
3. Keep the existing "Market Insight" content-carousel section as-is
   structurally (it already exists per the file's doc comments); recolor
   its dark hero-card treatment (base-fill gradient, bar-chart art glow,
   eyebrow/headline/description text, "Read more" pill, pager arrows/label)
   per the Component table.
4. Full `home_tab.dart` verification pass now that both Home phases are
   complete.

### Phase 4 — Insights tab

Recolor per Phase 0 (automatic).

1. Sentiment gauge card: structurally close to what `insights_tab.dart`
   already renders (doc comments confirm a sentiment gauge already
   exists) — keep the layout, recolor per §2A's Component table (arc
   fill, unfilled track, end-cap dot, qualitative-label pill).
2. Grouped mover lists (Top Gainers / Top Losers / Most Active): recolor
   the row grammar (tile + name/ticker + price + colored delta), each
   list under an uppercase section label with a "See all" affordance.
   **Do not add a per-row sparkline** — §3 confirms the backend supplies
   no series data for movers.
3. Apply the remaining structural refinements from §2.2 where the current
   implementation diverges — treat each as a targeted diff, not a rewrite.

### Phase 5 — Learn tab

Recolor per Phase 0 (automatic).

1. Page header: small uppercase eyebrow ("TRADING LIBRARY"), large bold
   title, muted subhead — reuse the Home header's type roles.
2. Build a shared stat-tile component (icon-less, bold number over muted
   label) and use it for the two Learn stat tiles (e.g. "0 Subjects",
   "0 Courses"). This component is reused by Profile in Phase 6 — build it
   once here rather than duplicating it there.
3. Horizontal pill-tab filter row (All / Basics / Technical / Fundamental /
   Psychology), active pill filled solid in `accent`.
4. Re-skin the existing empty-state concept in `learn_tab.dart` /
   `state_views.dart` toward a calmer, centered composition (small glyph,
   bold message, muted explanation, small circular "pull to retry").
5. Footer info card (icon tile + heading + description), same card
   language as elsewhere.

### Phase 6 — Profile & Settings

Recolor per Phase 0 (automatic). `profile_tab.dart` / `settings_screen.dart`
are already structured close to the reference — treat this as **re-skin +
targeted layout adjustment**, not a rebuild.

1. Profile header: circular avatar/initials using the identity-accent
   lavender/plum tone from §2A (never brand green), name, handle, a small
   pill tag top-right, muted tagline, "Edit Profile" pill button.
2. Reuse the shared stat-tile component from Phase 5 for Profile's two
   stat tiles (e.g. alerts logged / unread insights) instead of building a
   second one.
3. Recolor the grouped rows under ACCOUNT / PREFERENCES / SUPPORT / ABOUT
   (leading label + optional two-line description, trailing value/chevron)
   — structure already matches, re-skin only.
4. Settings' appearance section: adjust the Light/Dark selector and the
   Small/Default/Large text-size selector to the "big tappable tile" style
   (glyph + label + checkmark on the selected tile / "Aa" at each scale) if
   the current implementation renders them as a thinner bar — keep the
   underlying logic untouched.
5. Recolor toggle rows (`AyreSwitch` usage) — label + description +
   trailing switch. Leave the "Delayed-data warnings" notification-
   preference toggle itself untouched (§4 — it's a user preference, not a
   market-data display).

### Phase 7 — Secondary screens, cleanup & auth verification

1. Sweep the remaining secondary screens (`signals_tab.dart`,
   `equity_detail_screen.dart`, `index_detail_screen.dart`,
   `edit_profile_screen.dart`, `notifications_screen.dart`,
   `support_screen.dart`, `login_screen.dart`, `splash_screen.dart`,
   `lesson_screen.dart`) for recoloring consistency per Phase 0's tokens.
2. Remove the two remaining "Delayed" chip occurrences
   (`equity_detail_screen.dart`, `index_detail_screen.dart`) and fix
   `FreshnessStamp` in `state_views.dart`, per §4's table.
3. Update `test/fault_states_test.dart` per §4's table.
4. **Auth bypass verification.** `lib/main.dart` already defines
   `const bool kEnableAuthStartupGate = false;` and
   `_StartupGateState._check()` already routes straight to `HomeShell`
   when that flag is false, skipping `ApiService.loadSavedCookie()` /
   `getSession()` entirely. Separately, the backend's
   `_require_authentication` helper (`main.py` L328) is defined but
   **never called** by any route — so even if a request went out without a
   session cookie, no consumer-facing endpoint would reject it. **The
   sign-in requirement is therefore already bypassed on both sides.** This
   step is verification, not new work:
   a. Confirm `kEnableAuthStartupGate` is `false` and add a short code
      comment (if not already present) explaining it's the single switch
      to flip to restore the startup login gate later.
   b. Confirm no other screen forces a login redirect on startup (check
      `HomeShell`, `ProfileTab._loadIdentity`, `SettingsScreen._loadSession`
      — these call `ApiService.getSession()` for optional personalization
      only, and already degrade gracefully to blank/default values when it
      returns `null`; they do not redirect).
   c. Leave `LoginScreen`, `ApiService.login/logout/getSession`, and the
      `SessionExpiredScreen` flow fully intact — do not delete any of it.
   d. Log the verification outcome in §7; no files should need to change
      here unless step (b) finds an exception to the above.

## 6. What NOT to do (explicit guardrails)

- Do not touch `ayre-scanner-main/frontend/` (the website) at all.
- Do not add, remove, or modify any backend route or response field.
- Do not invent trace/sparkline/O-H-L data for indices or movers.
- Do not run or reference `flutter analyze` as a plan step.
- Do not substitute, approximate, or "improve on" any hex value in §2A —
  it is the canonical spec. If a value genuinely fails a contrast check
  (Phase 0 step 3), adjust only that value, record the change and the
  reason in the Phase 0 log entry, and keep everything else as specified.
- Do not rename the app, package, or any `Ayre*` class/file — the app
  keeps the Ayre name. This plan is a visual redesign (v5) only.

## 7. Phase Log

_Update after each phase. Keep entries concise: what shipped, files
touched, deviations/discoveries, what's left._

### Phase 0 — Theme tokens
**Done.** Files changed: `lib/theme/app_theme.dart`.

- Replaced every `Color(0x...)` literal in `_light` and `_dark` with §2A's
  core-token table values, field for field (verified programmatically
  against the spec — all 46 values match exactly). No `AppThemeTokens`
  field added or removed.
- Retitled the file's top banner comment from "v4" to "v5" and rewrote every
  doc comment that named the retiring "clay/terracotta", "sage/rose/gold",
  or "v4 calm, editorial, premium" identity (the class banner, and the
  `background`/`accent`/`accentInk`/`positive`/`negative`/`neutral`/
  `onAccent` field docs, plus the `_light`/`_dark` block header comments and
  their inline accent/onAccent contrast notes). Left the file's other
  "New in v4" notes as-is (motion/type-scale history, unrelated to palette
  naming).
- Contrast pass (step 3): computed WCAG ratios for every
  `textPrimary`/`foregroundMuted`/`foregroundSubtle` pairing against
  `background`/`surface`, and `onAccent` against `accent`, in both themes.
  All `textPrimary` pairings clear ≥15:1 (well past the 4.5:1 requirement)
  in both themes. **One flagged deviation, not silently changed:** light
  `onAccent` (`#FFFFFF`) against light `accent` (`#1F8A4B`) measures
  **~4.38:1**, just under the 4.5:1 AA threshold for normal-size text (the
  button-label typography this pairs with renders at 14px/700, below the
  ~18.66px-bold "large text" cutoff, so the 3:1 large-text allowance doesn't
  apply). White is already the maximum achievable luminance for `onAccent`,
  so no local tweak closes the gap, and `accent` itself is canonical per the
  plan's guardrails — left as specified, documented in-code at the
  `onAccent` field in `_light`, flagging it here for design review rather
  than deviating unilaterally. `accentInk` (light) was confirmed genuinely
  needed: raw `accent` measures only ~4.03–4.38:1 as small text on
  `background`/`surface`, so the darker `accentInk` value (~6.0–6.6:1) is
  doing real work, not redundant with `accent`.
- Added the Index-card identity tints lookup (step 6) as a new
  `AppIndexTint` class + `AppIndexId` enum + `AppIndexTints` static
  light/dark `Map` lookup in `app_theme.dart` (single shared location, per
  the plan's instruction, for both `home_tab.dart` and
  `index_detail_screen.dart` to consume in later phases). All 30 values
  (3 indices × 5 fields × 2 themes) verified against §2A's second table.
- `AppRadius`, `AppSpace`, `AppTextScale`, and `AppTypo`'s fonts were left
  untouched, as required — only color *arguments* change.
- No deviations beyond the flagged `onAccent` contrast note above. Nothing
  else in the file (motion, radii, text scale, theme builder, page
  transitions) was touched.
- What's left: Phase 1 (re-skin shared components) is next.

### Phase 1 — Shared components
**Done (not compiled — see "Verification" below).** Files changed:
`lib/widgets/ayre_bottom_nav.dart`, `lib/widgets/ayre_components.dart`,
`lib/widgets/ayre_charts.dart`, `lib/widgets/ticker_trace.dart`,
`lib/widgets/state_views.dart` (comments only), `lib/widgets/ayre_icons.dart`
(one comment only). `figure.dart` needed no change.

**Audit (step 1).** Grepped all seven Phase 1 files for `Color(0x…)`,
`Color.fromARGB/RGBO`, and `Colors.*`. **No old clay/rose/gold hex value
exists outside `app_theme.dart`.** The only literal is
`Color(0xFF000000)` in `ayre_icons.dart` (~L115), a neutral last-resort icon
fallback behind `color ?? IconTheme.color`, not a palette color — left as-is.
`figure.dart` and `ayre_icons.dart` already read every color from tokens.
The work was therefore not hex-hunting but bringing components into line with
§2A's *component* table, which Phase 0 (tokens only) did not touch.

**Changes, by §2A row:**
- **Bottom nav** (`ayre_bottom_nav.dart`): restructured from a flat
  full-width, edge-flush glass bar into a **floating pill** — 12px margin on
  left/right/bottom (plus safe-area inset), `AppRadius.pill` clip, full-
  perimeter `navHairline` border, two-layer `shadowColor` shadow (drawn on a
  `DecoratedBox` *outside* the `ClipRRect` so the clip doesn't cut it off).
  `navBg` alpha 0.90 light / 0.85 dark (was a flat 0.66). Active pill is now
  **solid**: `textPrimary` (light) / `accent` (dark), was a 14% accent wash.
  Active content white / `onAccent`; inactive `#8B948E` light /
  `foregroundMuted` dark (was `accentInk` / `foregroundSubtle`). Blur +
  saturation matrix and spring-driven pill motion are unchanged. Added
  `AyreBottomNav.edgeMargin` and `.occupiedHeight` constants.
  *Deviation:* the two light-only literals (`#FFFFFF`, `#8B948E`) live as
  file-private helpers in this file, not `AppThemeTokens` fields, because §2A
  lists them as component-specific and Phase 0 forbids adding token fields.
- **LIVE chip** (`AyreChip`, `ChipTone.live`): now `positive` on
  `positiveSoft` (was `neutral` gold on `neutralSoft`), per §2A's LIVE row.
  `ChipTone.attention` stays gold.
- **Switch** (`AyreSwitch`): off-track `surfaceSunken` (was `surfaceRaised`).
  *Deviation:* off-knob lifted `foregroundSubtle` → `foregroundMuted`. On the
  spec'd sunken track the subtle tone measures **2.54:1** in light (< 3:1
  non-text floor); muted measures 4.68:1 light / 8.6:1 dark.
- **Sparkline fill** (`ticker_trace.dart`): area-fill start alpha is now
  **0.30 light / 0.35 dark** → 0.0 (was a fixed 0.22), threaded to the painter
  as `fillAlpha` and included in `shouldRepaint`.
- **Sentiment gauge** (`ayre_charts.dart`): end-cap is now a **solid** dot in
  the fill color (was surface-filled with a 2px accent ring); band label is a
  **pill** (`accentInk` on `accentSoft`). When a caller passes a directional
  `tone` (Home and Insights both do), the pill follows that tone (14% wash +
  tone text) so a red arc never sits over a green label. Track was already
  `surfaceSunken`; fill already `accent` by default.
  *Deviation:* end-cap radius is `thickness / 2` (flush with the stroke), not
  larger. A 0.62×-thickness dot was tried and rejected: it overhangs the
  176×88 paint box by up to ~1.3px at the sides and ~1.3px above at score 50,
  which clips. Nothing that would grow the gauge's layout box was added, so
  Home/Insights layouts (`132 + 176 + gap` pairing) are unaffected.
- **Stale wording**: rewrote v4/clay/sage/rose/"warm"/"previous identity"
  comments in the touched files to describe v5. Left as accurate history:
  `ayre_icons.dart`'s "v4 redraw" notes (they describe a real v3→v4 glyph
  redraw decision), `ayre_components.dart` L~1080 ("previous identity's
  whole-block opacity pulse"), and `ayre_bottom_nav.dart`'s "sage-gray"
  (that is §2A's literal description of `shadowColor`).

**Explicitly not done (assigned elsewhere by the plan):** the `FreshnessStamp`
"Delayed" chip and `StaleNotice`'s "Data may be delayed" copy in
`state_views.dart` → Phase 7 (§4 / Phase 7 step 2). `AyreGlyph.delayed` kept.
The `ayre_components.dart` doc comments that named "DELAYED" as an example
state were reworded (§4's low-priority row) since that file was open.

**Sentiment card / Market Insight card / hill decorations / index-tile
gradient / avatar chip** (other §2A component rows) are *screen-level*
components, not shared widgets — deferred to Phase 2/3, not this phase.

**Verification.** No Flutter/Dart SDK was reachable from the build sandbox
(`storage.googleapis.com` is blocked), so **nothing was compiled, analyzed, or
run — not `flutter analyze`, not `flutter test`.** Checks actually performed:
bracket balance per edited file; every token/identifier/import the edits rely
on resolved by name; no dangling references to removed symbols; geometry of
the gauge end-cap swept over every score 0–100; WCAG ratios recomputed for
the switch knob. **Please run `flutter test` on your machine before Phase 2.**
Specific risks to look at first: `test/layout_matrix_test.dart` (nav hit
targets ≥44×48 at 320×568 — each `_NavItem` is still 64px tall, so this
should hold; and a taller/floating bar at that small size), and any golden
or finder test touching the gauge's band label (now inside a pill; text
content unchanged).

**Known open item carried from Phase 0:** light `onAccent` (#FFFFFF) on
`accent` (#1F8A4B) is ~4.38:1 — under AA for normal text. It now also applies
to the light active segmented-control/filter-chip labels. Left per the
canonical-spec guardrail; flagged for design review.

**What's left:** Phase 2 (Home tab: header & sentiment card).

### Phase 2 — Home tab: header & sentiment card
**Done (not compiled — no Flutter/Dart SDK available; see "Verification").**
Files changed: `lib/screens/home_tab.dart`. New files:
`lib/widgets/ayre_hills.dart`, `lib/widgets/ayre_avatar.dart` (both shared —
Phase 6's Profile header reuses them rather than rebuilding).

- **"Delayed" chip (§4, `home_tab.dart`):** stale index card renders nothing
  in the chip slot. Implemented as omission of the slot (`if (!stale)`)
  rather than `SizedBox.shrink()` inside `ShrinkTrailing` — same visible
  result, no zero-size `FittedBox` child, no dangling gap. `FreshnessStamp`
  (Index-board label trailing) and `StaleNotice` copy are untouched → Phase 7.
- **Header:** salutation is now time-of-day ("Good morning/afternoon/
  evening," device clock; <12 / <17 / else) over the name, with the name the
  larger/bolder line, plus the muted subhead "Discipline today. A better
  tomorrow." (§2.1 copy). Built from existing roles only (`display` at
  `AppTextScale.featuredHeadline` w500 over `pageTitle`; `body` for the
  subhead). No name → salutation alone at `pageTitle`. Wordmark row kept.
  Replaces "Hi, name"/"Hi there".
- **Header buttons:** theme toggle + bell are now flat 44pt circles — fill
  `surface` (#FFFFFF) light / `surfaceRaised` dark, glyph `textPrimary`,
  unread dot `negative` (was `accent`), ringed in the button's own fill.
  Hairline border kept for edge definition. *Deviation:* no search button
  added — the app has no search feature and §6 forbids inventing one; the
  theme toggle (spec'd in the Home spec, covered by a test) stays.
- **Avatar:** header avatar is the §2A identity chip (lavender/plum; light
  `#E1DDF5`/`#4B3F73`, dark `#241F38`/`#C9BFEA`) via new shared `AyreAvatar`.
  Values are component-specific literals living in that file (Phase 0 forbids
  new token fields).
- **Hills:** new shared `AyreHills` — three offset ellipses at the top-right
  corner using §2A's exact alpha-layered `accent` ARGB values (light
  `0A/14/1F` of `#1F8A4B`, dark `0C/16/20` of `#3FCB7A`). `IgnorePointer` +
  `ExcludeSemantics`; pure ornament. Placed as a `Stack` backdrop to the
  header, bleeding past the list padding to the viewport's top-right.
- **Market Sentiment card** (`_SentimentCard`, now directly under the header
  and above the index board): icon (`AyreGlyph.instrument`) + "Market
  Sentiment" label, bucket word set in `pageTitle` with `trendUp`/`trendDown`
  glyph (Neutral: no glyph, per `DirectionBadge` convention), one-line
  description. Gradient/label/description colors are §2A's literals
  (`_SentimentCardColors`); the word/glyph reuse `positive`/`neutral`/
  `negative`. **Breakpoints: <35 Bearish · 35–64 Neutral · ≥65 Bullish** —
  deliberately the same cut points as `Sentiment.band` and the Insights
  gauge's tone, so one score never reads as two moods. **Description order:**
  API `note` → "X of Y stocks advancing" from the sentiment feed's own
  advances/declines(/unchanged) → same from full-Nifty-500 `FullBreadth` →
  generic line with no numbers. Own skeleton, failed and empty states. Score
  is not shown visually (reference card doesn't); it's in the semantics label.
- **Gauge removed from Home; donut kept.** The old breadth section paired the
  donut with a `SentimentGauge`. The gauge's role is now the sentiment card
  (and it remains on Insights, where §2A places it). `_BreadthCard` is now
  donut-only, reading `FullBreadth` alone, with its own skeleton/failed/empty
  states — sentiment and breadth can no longer blank each other. Removed as
  dead: `_band`, `_BreadthSlotNotice`. Entrance stagger indices shifted by one
  after the new card.
- **Contrast — flagged, left as spec'd (not silently changed):** in light,
  §2A's description color `#64766B` on the sentiment gradient measures
  ~4.0–4.3:1 (<4.5 for 13.5px body text); the Neutral word in `neutral`
  `#C98A2D` on that gradient measures ~2.4–2.6:1 (<3:1 large-text floor).
  Bullish/Bearish (~3.6–3.9:1) pass the large-text floor; label text
  (~5.3–5.8:1), all dark-theme pairings (≥5.2:1), avatar (7.0/9.1:1) and
  header glyphs (≥14:1) are fine. For design review.
- **Discoveries for later phases:**
  1. **Phase 3 step 3 assumes a "Market Insight" carousel already exists in
     `home_tab.dart`. It does not** (no carousel, pager or hero card anywhere
     in `lib/`). Phase 3 must *build* it (with a content source — none exists
     in the backend) or the step must be rescoped.
  2. `_FooterLine` still says "Levels are indicative and may be delayed" —
     a disclaimer, not in §4's inventory, left as-is; say if it should go.
  3. `test/identity_test.dart` (~L44-64, L80-110) still asserts the v4
     clay/sage/rose palette (e.g. accent `#D26A4C`) and will fail since
     Phase 0. Not part of this phase; needs updating to v5 values.
- **Verification.** Not compiled/analyzed/run. Performed: bracket balance on
  all three files; every identifier/token/constructor used resolved by name
  against the source; WCAG ratios computed for every new color pairing.
  `test/fault_states_test.dart` (~L237, `find.text('DELAYED')` on stale Home)
  should still pass because `FreshnessStamp` still renders its chip until
  Phase 7. Layout-matrix risks to check first: Home header at 320px × 2.0
  text scale (three 44pt controls beside a wrapping greeting/subhead) and the
  sentiment card at the same size.
- **What's left:** Phase 3 (index cards, graph-area flourish, Market Insight
  carousel).

### Phase 3 — Home tab: index cards, graph area & Market Insight carousel
**Done (not compiled — no Flutter/Dart SDK available).** Files changed:
`lib/screens/home_tab.dart`, `lib/widgets/ayre_icons.dart` (new `bank` glyph),
`test/support/fake_market_data.dart` (3 insight notes instead of 1). New files:
`lib/widgets/ayre_index_art.dart`, `lib/widgets/ayre_insight_carousel.dart`,
`lib/screens/insight_note_screen.dart`, `test/home_phase3_test.dart`.

- **Index cards (§2.1, §2A):** card fill is the index's identity tint
  (`AppIndexTints`, via new shared `AyreIndexIdentity`, resolved by symbol
  then label; an unknown index gets a neutral token-built identity, never
  another index's tint). Header is a **circular** radial-gradient icon tile
  (`AyreIndexIconTile`) + name over exchange sub-label + LIVE chip opposite.
  Glyphs: NIFTY 50 `trendUp`, SENSEX `instrument`, BANK NIFTY new
  `AyreGlyph.bank` (no existing glyph read as a bank). Exchange labels
  (NSE/BSE/NSE) are static facts, not market data. Level/change/link
  structure unchanged; clock text moved `subtle` → `muted` (subtle is ~2.6:1
  on the tints). Skeleton mirrors the new header.
- **Graph area (§3):** no sparkline, period tabs or O/H/L added. When
  `trace` is empty, `AyreIndexFlourish` draws three translucent domes in the
  tint's `trace` colour *behind* the level/change block (Stack backdrop, adds
  no layout; alphas 0.10/0.16/0.24 light, 0.12/0.20/0.30 dark — derived
  washes, no new hue). The `trace.length >= 2` branch is untouched and
  replaces the flourish automatically. No `LayoutBuilder` (Home's wide layout
  uses `IntrinsicHeight`). `activePeriodTabFill` stays unused until a real
  series exists.
- **Market Insight carousel — built, not recoloured.** The Phase 2 log said
  no content source exists; one does: `GET /api/insights` (admin-curated
  notes), already wired as `MarketDataService.getInsightNotes()` and used by
  Insights. The carousel pages those real notes (featured first, max 5;
  eyebrow = category or "Market insight"; headline = title; description =
  body, 2-line clamp; "Read more" only when a body exists, opens new
  `InsightNoteScreen`). Pager ‹ 01/0N › hidden for a single note; arrows wrap;
  horizontal swipe supported. Pages cross-fade in one `Stack` (no `PageView`),
  so height is content-sized and stable at any text scale. Loads in `_load`
  only (not the 10s tick). Empty desk → section and gap omitted; failed →
  compact `StatePanel.failed`; loading → skeleton. All §2A colours used
  verbatim. **Derived:** bar colour is not in §2A — bars reuse the glow's own
  opaque hue (`#2E9E5B` / `#4ED892`) with a 0.22→0.80 alpha ramp.
  **Deviation:** description clamps to 2 lines, not the reference's 1.
- **Contrast — flagged, left as spec'd:** light-theme delta figures
  (`positive`/`negative` 15px) on the identity tints measure ~3.7–3.8:1
  (<4.5); light icon-tile glyphs (`trace` on gradient) ~1.9–3.7:1
  (decorative, name beside them). Dark tints and the whole hero card
  (≥6.8:1) are fine; `muted` on tints ≥4.8:1.
- **Discoveries:** `test/identity_test.dart` still asserts v4 palette (fails
  since Phase 0). `_FooterLine` "may be delayed" disclaimer untouched.
  `index_detail_screen.dart` should adopt `AyreIndexIdentity` /
  `AyreIndexIconTile` in Phase 7.
- **Verification.** Not compiled/analyzed/run. Bracket balance checked on
  all edited files; identifiers resolved by name; WCAG ratios computed. Run
  `flutter test` — check first: `layout_matrix_test` Home sweeps at
  320×568 ×2.0 (card header, carousel), `home_phase3_test`. Fake data trace
  is non-empty, so sweeps exercise the sparkline branch, not the flourish.
- **What's left:** Phase 4 (Insights tab).

### Phase 4 — Insights tab
**Done (not compiled — no Flutter/Dart SDK; Dart syntax-parsed only, 0 errors).** Files changed: `lib/screens/insights_tab.dart`, `lib/widgets/ayre_components.dart` (`RowGroup.indent`, `SkeletonTickerRow.tile`). New: `lib/widgets/ayre_instrument_tile.dart`, `test/insights_phase4_test.dart`.

- **Sentiment card:** gauge paired beside the feed's real `note` + a breadth line ("X of Y stocks advancing", "declining" when decliners > advancers, trend glyph). Each omitted when the feed lacks it; gauge alone if both absent. Paired (gauge width 148) at inner width ≥296 and text scale ≤1.3, else stacked (176). Old bottom note block removed (moved beside gauge); donut kept.
- **Gauge tone:** bullish (≥65) passes no tone → §2A accent fill/end-cap/`accentInk`-on-`accentSoft` pill. Neutral/bearish keep directional gold/red (decision #12). Deviation from a literal "always accent".
- **Movers rows:** `AyreInstrumentTile` (rounded-square monogram, `surfaceRaised`/`foregroundMuted`, never direction-tinted) as `TickerRow.leading`. Rank numeral dropped. Symbol-over-name order kept (not name-over-ticker). Dividers indent to text. No sparkline (§3).
- **"See all":** in-place expand 5 → all (backend max 10); only when >5 rows; state survives the 10s refresh. Freshness stamp kept beside it; stamp dropped above 1.3× text scale.
- **Flagged:** "See all" tap height ~35pt (<44) → Phase 7 target pass. `FreshnessStamp` "Delayed" chip untouched (Phase 7). `index_detail_screen.dart` / `equity_detail_screen.dart` instrument lists should adopt `AyreInstrumentTile` in Phase 7. `test/identity_test.dart` still asserts v4 palette.
- **Check first when running tests:** `layout_matrix_test` (Insights sentiment card at 390 / 2.0×), `fault_states_test` `find.text('71')`, `insights_phase4_test`.
- **What's left:** Phase 5.

### Phase 5 — Learn tab
**Done (not compiled; syntax-parsed only).** Files changed: `lib/screens/learn_tab.dart`, `lib/widgets/state_views.dart` (new `CalmStatePanel`). New: `lib/widgets/ayre_stat_tile.dart`, `test/learn_phase5_test.dart`.

- **Header:** eyebrow / title / new subhead "Build your edge, one lesson at a time." (placeholder copy).
- **`AyreStatTile`** (shared; optional `glyph` for Phase 6 Profile): Subjects + Courses tiles. Show "—" while loading or after a failure, true 0 when empty.
- **Filter pills:** reuse `AyreFilterChip` (solid accent when active). Built from the loaded courses' real `category` values (All + first-seen order), hidden with <2 subjects — the reference's Basics/Technical/etc. are examples, not backend data. Continue card ignores the filter.
- **`CalmStatePanel`:** card-less centered glyph, bold line, muted line, 44pt circular refresh (accessible name = §14.5 verb). Used for Learn empty and failed. `StatePanel` unchanged.
- **Footer info card:** static, always shown; copy "For learning, not advice" is a placeholder for design review.
- **Not touched:** multi-column course grid (only receives the filtered list).
- **What's left:** Phase 6.

### Phase 6 — Profile & Settings
_Not started._

### Phase 7 — Secondary screens, cleanup & auth verification
_Not started._